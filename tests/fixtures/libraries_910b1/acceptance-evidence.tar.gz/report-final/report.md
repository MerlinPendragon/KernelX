# 910B1 采集效率试采报告

这是冻结目录的试采结果。full 仅表示该版本选定入口的三个 shape，不代表上游全部 API。

| 库 | 计划 case | 成功/attempt | 有效不同 case | 热缓存 p50 秒 | 状态 |
| --- | ---: | ---: | ---: | ---: | --- |
| cann-opp | 1 | 3/4 | 1 | 23.5073764105 | MEASURED_SEED |
| ops-nn | None | 0/0 | 0 | None | ADAPTER_UNCONFIGURED |
| ops-transformer | None | 0/0 | 0 | None | ADAPTER_UNCONFIGURED |
| sgl-kernel-npu | 1 | 0/0 | 0 | None | UNSUPPORTED |
| tile-kernels | 1 | 0/0 | 0 | None | UNSUPPORTED |
| deepgemm-ascend | 1 | 0/0 | 0 | None | UNSUPPORTED |
| deepep-ascend | 1 | 0/0 | 0 | None | UNSUPPORTED |

资源账本：`{"actual_server_hours": 0.024184542894363403, "actual_card_hours": 0.005423509147432115, "actual_chip_hours": 0.005423509147432115, "global_wall_seconds": 87.06435441970825, "reserved_server_hours": 0.0830556325117747, "reserved_card_hours": 0.0830556325117747, "reserved_chip_hours": 0.0830556325117747, "cpu_seconds": null, "measured_collector_cpu_lower_bound": 46.60699700000001, "io_bytes": null, "import_latency_seconds": null}`

三窗口不能替代三天。跨日、跨卡、跨机稳定性和未运行库的容量保留为待测；未知成本保留 null。预热维持 20 次。

60/90/120 分钟容量与输入哈希见 capacity.csv、report.json 和 inputs.json。预测仅适用于已测的冻结 seed，不能外推到未测算子族。
